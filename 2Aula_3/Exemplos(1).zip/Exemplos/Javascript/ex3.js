// JavaScript Document
alert("Arquivo externo....");

